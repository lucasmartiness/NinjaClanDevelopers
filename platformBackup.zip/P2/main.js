var Q;

	main();
	//var nomeFaze = "faze1.tmx";			
	var nomeFaze = "faze1.tmx";			
	var faze = 1;				

function main(){
	
	
		
    Q = Quintus() //inicia a quintus
		.include("Sprites, Scenes, Input, 2D, Touch, UI, Anim ") 		                                		          //adiciona os m󤵬os que ser䯠utilizados
		.setup({//setup inicial cria o tamanho do canvas 
			width: 960,
			height: 640
		})
		.controls()
		.touch(); // controles base  
		
		Class();
		
		//carrega a 1 faze
		//var load = "RockRunSpriteSheet.png,tilesmap.png,Rocksingle.png,player.json,"+nomeFaze
		Q.load("RockRunSpriteSheet.png,tilesmap.png,Rocksingle.png,player.json,faze1.tmx,faze2.tmx,faze3.tmx" , Loadlevel);
		
		
		Q.scene ("level1", RunLevel1 ); 	
		Q.scene ("level2", RunLevel2 ); 	
		Q.scene ("level3", RunLevel3 ); 		
		//Q.scene ("level3", RunLevel1 ); 	
				
}
function Class(){
	
	
		
		
		Q.Sprite.extend("Player", {
					init: function(p)
					{	
						this._super(p, 
						{ 
						//asset:'Rocksingle.png',
						sheet:'player',
						sprite:'player',
						//asset: "player.png",//  agora não é mais asset mais agora é animação
						x: 15, y:10,cy:34,
						jumpSpeed: -380,
						direction: "right",
						scale: 0.8,// diminui o tamanho do personagem
						
						});	
					//	 Q.input.on("fire",this,"fireWeapon");
						this.add('2d, platformerControls,animation ');
					},
					
					step:function(dt){
						
						
						//console.log(this.p.x);
						if( this.p.x >= 6272){
							//document.write('dt');
							
							if(faze == 1)
								Q.stageScene("level2");
							if(faze == 2)
								Q.stageScene("level3");
							
							faze++;
							//console.log(this.p.x);
							
						}
						if(Q.inputs['left'] && this.p.direction == 'right') {
								
								this.p.flip = 'x';		
							} 
							if(Q.inputs['right']  && this.p.direction == 'left') {
								  
								this.p.flip = false; 						
							}
							
							if(this.p.vx != 0){
								this.play("walk_"+this.p.direction);
							}
							else{
								this.play("stand_"+this.p.direction);
							}
						
					}
					
										
		});
		
	
	
}
function RunLevel1(stage) {
	
	var nome;
		
	//nome = 'faze1.tmx';
	nome = nomeFaze;
	
		 	var background = new Q.TileLayer({
		
			dataAsset: nome, //carrega level1.tmx
			layerIndex: 0, //layer  de fundo (background layer tiled) 
			sheet: 'tiles', // o tileshet apelidado em Q.Load
			tileW: 64, //sincroniza o  tamanho de tile utilizado
			tileH: 64, 
			type: Q.SPRITE_NONE ,// define agrupamento
		 			 }
			 );
			 
			var l1 = new Q.TileLayer({
		
			dataAsset: nome, //carrega level1.tmx
			layerIndex:1, //layer  de fundo (background layer tiled) 
			sheet: 'tiles', // o tileshet apelidado em Q.Load
			tileW: 64, //sincroniza o  tamanho de tile utilizado
			tileH: 64, 
			type: Q.SPRITE_NONE ,// define agrupamento
		 			 }
			 );
			var l2 = new Q.TileLayer({
		
			dataAsset: nome, //carrega level1.tmx
			layerIndex:2, //layer  de fundo (background layer tiled) 
			sheet: 'tiles', // o tileshet apelidado em Q.Load
			tileW: 64, //sincroniza o  tamanho de tile utilizado
			tileH: 64, 
			type: Q.SPRITE_NONE ,// define agrupamento
		 			 }
			 );

			var l3 = new Q.TileLayer({
		
			dataAsset: nome, //carrega level1.tmx
			layerIndex:3, //layer  de fundo (background layer tiled) 
			sheet: 'tiles', // o tileshet apelidado em Q.Load
			tileW: 64, //sincroniza o  tamanho de tile utilizado
			tileH: 64, 
			type: Q.SPRITE_NONE ,// define agrupamento
		 			 }
			 );
			
			var l4 = new Q.TileLayer({
		
			dataAsset: nome, //carrega level1.tmx
			layerIndex:4, //layer  de fundo (background layer tiled) 
			sheet: 'tiles', // o tileshet apelidado em Q.Load
			tileW: 64, //sincroniza o  tamanho de tile utilizado
			tileH: 64, 
			type: Q.SPRITE_NONE ,// define agrupamento
		 			 }
			 );
			
			
			
			var platform = new Q.TileLayer({
			dataAsset: nome, //carrega level1.tmx,
			layerIndex:5, // collision layer feito no tiled
			sheet: 'tiles', //tilesheet carregado em Q.load
			tileW: 64, //sincroniza o padr䯠de tamanho de tile
			tileH: 64 ,
			 type: Q.SPRITE_DEFAULT,
			
			});
			
			
			
			stage.insert(background); //coloca elementos na cena
			stage.insert(l1); //coloca elementos na cena
			stage.insert(l2); //coloca elementos na cena
			stage.insert(l3); //coloca elementos na cena
			stage.insert(l4); //coloca objetos na cena
			stage.collisionLayer(platform); //cria um layer de colis



		// carrega o platform

		// add player
		var player = stage.insert(new Q.Player());
		stage.add("viewport").follow(player,{x: true, y: true},{minX: 0, maxX: background.p.w, minY: 0, maxY: background.p.h});
		
		
}

function RunLevel2(stage) {
	
	var nome;
		
	nome = 'faze2.tmx';
	//nome = nomeFaze;
	
		 	var background = new Q.TileLayer({
		
			dataAsset: nome, //carrega level1.tmx
			layerIndex: 0, //layer  de fundo (background layer tiled) 
			sheet: 'tiles', // o tileshet apelidado em Q.Load
			tileW: 64, //sincroniza o  tamanho de tile utilizado
			tileH: 64, 
			type: Q.SPRITE_NONE ,// define agrupamento
		 			 }
			 );
			 
			var l1 = new Q.TileLayer({
		
			dataAsset: nome, //carrega level1.tmx
			layerIndex:1, //layer  de fundo (background layer tiled) 
			sheet: 'tiles', // o tileshet apelidado em Q.Load
			tileW: 64, //sincroniza o  tamanho de tile utilizado
			tileH: 64, 
			type: Q.SPRITE_NONE ,// define agrupamento
		 			 }
			 );
			var l2 = new Q.TileLayer({
		
			dataAsset: nome, //carrega level1.tmx
			layerIndex:2, //layer  de fundo (background layer tiled) 
			sheet: 'tiles', // o tileshet apelidado em Q.Load
			tileW: 64, //sincroniza o  tamanho de tile utilizado
			tileH: 64, 
			type: Q.SPRITE_NONE ,// define agrupamento
		 			 }
			 );

			var l3 = new Q.TileLayer({
		
			dataAsset: nome, //carrega level1.tmx
			layerIndex:3, //layer  de fundo (background layer tiled) 
			sheet: 'tiles', // o tileshet apelidado em Q.Load
			tileW: 64, //sincroniza o  tamanho de tile utilizado
			tileH: 64, 
			type: Q.SPRITE_NONE ,// define agrupamento
		 			 }
			 );
			
			var l4 = new Q.TileLayer({
		
			dataAsset: nome, //carrega level1.tmx
			layerIndex:4, //layer  de fundo (background layer tiled) 
			sheet: 'tiles', // o tileshet apelidado em Q.Load
			tileW: 64, //sincroniza o  tamanho de tile utilizado
			tileH: 64, 
			type: Q.SPRITE_NONE ,// define agrupamento
		 			 }
			 );
			
			
			
			var platform = new Q.TileLayer({
			dataAsset: nome, //carrega level1.tmx,
			layerIndex:5, // collision layer feito no tiled
			sheet: 'tiles', //tilesheet carregado em Q.load
			tileW: 64, //sincroniza o padr䯠de tamanho de tile
			tileH: 64 ,
			 type: Q.SPRITE_DEFAULT,
			
			});
			
			
			
			stage.insert(background); //coloca elementos na cena
			stage.insert(l1); //coloca elementos na cena
			stage.insert(l2); //coloca elementos na cena
			stage.insert(l3); //coloca elementos na cena
			stage.insert(l4); //coloca objetos na cena
			stage.collisionLayer(platform); //cria um layer de colis



		// carrega o platform

		// add player
		var player = stage.insert(new Q.Player());
		stage.add("viewport").follow(player,{x: true, y: true},{minX: 0, maxX: background.p.w, minY: 0, maxY: background.p.h});
		
		
}

function RunLevel3(stage) {
	
	var nome;
		
	nome = 'faze3.tmx';
	//nome = nomeFaze;
	
		 	var background = new Q.TileLayer({
		
			dataAsset: nome, //carrega level1.tmx
			layerIndex: 0, //layer  de fundo (background layer tiled) 
			sheet: 'tiles', // o tileshet apelidado em Q.Load
			tileW: 64, //sincroniza o  tamanho de tile utilizado
			tileH: 64, 
			type: Q.SPRITE_NONE ,// define agrupamento
		 			 }
			 );
			 
			var l1 = new Q.TileLayer({
		
			dataAsset: nome, //carrega level1.tmx
			layerIndex:1, //layer  de fundo (background layer tiled) 
			sheet: 'tiles', // o tileshet apelidado em Q.Load
			tileW: 64, //sincroniza o  tamanho de tile utilizado
			tileH: 64, 
			type: Q.SPRITE_NONE ,// define agrupamento
		 			 }
			 );
			var l2 = new Q.TileLayer({
		
			dataAsset: nome, //carrega level1.tmx
			layerIndex:2, //layer  de fundo (background layer tiled) 
			sheet: 'tiles', // o tileshet apelidado em Q.Load
			tileW: 64, //sincroniza o  tamanho de tile utilizado
			tileH: 64, 
			type: Q.SPRITE_NONE ,// define agrupamento
		 			 }
			 );

			var l3 = new Q.TileLayer({
		
			dataAsset: nome, //carrega level1.tmx
			layerIndex:3, //layer  de fundo (background layer tiled) 
			sheet: 'tiles', // o tileshet apelidado em Q.Load
			tileW: 64, //sincroniza o  tamanho de tile utilizado
			tileH: 64, 
			type: Q.SPRITE_NONE ,// define agrupamento
		 			 }
			 );
			
			var l4 = new Q.TileLayer({
		
			dataAsset: nome, //carrega level1.tmx
			layerIndex:4, //layer  de fundo (background layer tiled) 
			sheet: 'tiles', // o tileshet apelidado em Q.Load
			tileW: 64, //sincroniza o  tamanho de tile utilizado
			tileH: 64, 
			type: Q.SPRITE_NONE ,// define agrupamento
		 			 }
			 );
			
			
			
			var platform = new Q.TileLayer({
			dataAsset: nome, //carrega level1.tmx,
			layerIndex:5, // collision layer feito no tiled
			sheet: 'tiles', //tilesheet carregado em Q.load
			tileW: 64, //sincroniza o padr䯠de tamanho de tile
			tileH: 64 ,
			 type: Q.SPRITE_DEFAULT,
			
			});
			
			
			
			stage.insert(background); //coloca elementos na cena
			stage.insert(l1); //coloca elementos na cena
			stage.insert(l2); //coloca elementos na cena
			stage.insert(l3); //coloca elementos na cena
			stage.insert(l4); //coloca objetos na cena
			stage.collisionLayer(platform); //cria um layer de colis



		// carrega o platform

		// add player
		var player = stage.insert(new Q.Player());
		stage.add("viewport").follow(player,{x: true, y: true},{minX: 0, maxX: background.p.w, minY: 0, maxY: background.p.h});
		
		
}
function Loadlevel() 
{
				//prepara o tile set para carregar w = width, h= height
					Q.sheet("tiles","tilesmap.png", { tilew: 64, tileh: 64});  // apelido + imagem + tile 
					
					Q.compileSheets("RockRunSpriteSheet.png","player.json");
					
					
					
					Q.animations("player", {
					
					
						walk_right: { frames: [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14], rate: 1/15, flip: false, loop: true },
						walk_left: { frames:   [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14], rate: 1/15, flip:"x", loop: true },
						stand_right: { frames:[14], rate: 1/10, flip: false },
						stand_left: { frames: [14], rate: 1/10, flip:"x" },


					}
					);	
					/*
					
					
					
					/////////////////////////////////////////////////////////////////////////////
					////////////////////////////////////////////////////////////////////////////
					Q.compileSheets("player_anim.png","player.json");
					
					//spritesheet player, tera a lista de animações
					Q.animations("player", {
					
					
						walk_right: { frames: [0,1,2,3,4,5,6,7,8,9,10], rate: 1/15, flip: false, loop: true },
						walk_left: { frames:  [0,1,2,3,4,5,6,7,8,9,10], rate: 1/15, flip:"x", loop: true },
						stand_right: { frames:[14], rate: 1/10, flip: false },
						stand_left: { frames: [14], rate: 1/10, flip:"x" },


					}
					);	
					
						
					*/
					//carrega a cena inicial;
					Q.stageScene("level1");
					
						
				
}
			


function prototypeDefaultScene(stage) {
	
		  var box = stage.insert(new Q.UI.Container({
			x: Q.width/2, y: Q.height/2, fill: "rgba(0,0,0,0.5)"
		  }));
		  
		  var button = box.insert(new Q.UI.Button({ x: 0, y: 0, fill: "#CCCCCC",
												   label: "Play" }))         
		  var label = box.insert(new Q.UI.Text({x:10, y: -10 - button.p.h, 
												label: 'Start' }));
		  button.on("click",function() {
			Q.clearStages();
			Q.stageScene('stage1');
		  });
		  box.fit(20);
		
}

<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE tileset SYSTEM "http://mapeditor.org/dtd/1.0/map.dtd">
<tileset name="tilesmap" tilewidth="64" tileheight="64" tilecount="112" columns="14">
 <image source="../../images/tilesmap.png" width="896" height="512"/>
</tileset>
